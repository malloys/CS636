package cs636.pizza.presentation;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Set;

import cs636.pizza.config.PizzaSystemConfig;
import cs636.pizza.service.AdminService;
import cs636.pizza.service.ServiceException;
import cs636.pizza.service.StudentService;

import cs636.pizza.domain.PizzaOrder;
import cs636.pizza.domain.PizzaSize;
import cs636.pizza.domain.Topping;

//This class tests the full system.

public class SystemTest {

	private BufferedReader reader;
	private AdminService adminService;
	private StudentService studentService;
	private String inFile;

	public SystemTest(String inFile) {
		this.inFile = inFile;
		PizzaSystemConfig.configureServices();
		adminService = PizzaSystemConfig.getAdminService();
		studentService = PizzaSystemConfig.getStudentService();
	}

	public static void main(String[] args) {
		String inFile = null;
		if (args.length == 1) {
			inFile = args[0];
		} else  {
			System.out.println("usage:java <inputFile> ");
			System.exit(1);
		}
		SystemTest test = null;
		try {
				test = new SystemTest(inFile);
				test.run();
				System.out.println("Run complete, exiting");
		} catch (Exception e) {
			System.err.println("Error in run: StackTrace for it: ");
			e.printStackTrace();
			System.err.println("Error in run, shorter report: " + PizzaSystemConfig.exceptionReport(e));
		}
	}

	public void run() throws IOException, ServiceException {
		String command = null;
		reader = new BufferedReader(new FileReader(inFile));
		while ((command = getNextCommand()) != null) {
			System.out.println("\n\n*************" + command
					+ "***************\n");
			if (command.equalsIgnoreCase("ai")) { // admin init db
				adminService.initializeDb(); // create new tables, etc.
				adminService.addPizzaSize("small");
				adminService.addTopping("Pepperoni");
			} else if (command.equalsIgnoreCase("anr")) // admin next ready
				adminService.markNextOrderReady();
			else if (command.equalsIgnoreCase("aad")) // admin advance day
				adminService.advanceDay();
			else if (command.equalsIgnoreCase("acr")) { // admin college report
				List<PizzaOrder> report = adminService.getAdminReport();
				PresentationUtils.printReport(report, System.out);
			} else if (command.equalsIgnoreCase("adr")) { // admin daily report
				List<PizzaOrder> report = adminService.getDailyReport();
				PresentationUtils.printReport(report, System.out);
			} else if (command.startsWith("ss")) // student status
				handleOrderStatus(command);
			else if (command.startsWith("so")) // student order
				handleStudentOrder(command);
			else
				System.out.println("Invalid Command: " + command);
			System.out.println("----OK");
		}
		reader.close();
	}

	public String getNextCommand() throws IOException {
		String line = reader.readLine();
		return (line != null) ? line.trim() : line;
	}
	//TODO: get rid of StringTokenizer
	private void handleOrderStatus(String command) throws ServiceException {
		StringTokenizer tokenizer = new StringTokenizer(command);
		tokenizer.nextToken();
		int roomNumber = Integer.parseInt(tokenizer.nextToken());
		List<PizzaOrder> report = studentService.getOrderStatus(roomNumber);
		System.out.println("handleOrderStatus: first order: "+ report.get(0).getToppings().toArray(new Topping[1])[0].getToppingName());
		PresentationUtils.printOrderStatus(report, System.out);
	}

	private void handleStudentOrder(String command) throws ServiceException {
		StringTokenizer tokenizer = new StringTokenizer(command);
		tokenizer.nextToken();
		int roomNumber = Integer.parseInt(tokenizer.nextToken());
		Set<Topping> allToppings = studentService.getToppings();
		Set<PizzaSize> allPizzaSizes = studentService.getPizzaSizes();
		PizzaSize chosenPizzaSize = (PizzaSize) allPizzaSizes.toArray()[0];
		studentService.makeOrder(roomNumber, chosenPizzaSize, allToppings);
	}
}
