package cs636.pizza.config;

import org.eclipse.persistence.config.SessionCustomizer;
import org.eclipse.persistence.sessions.Session;
import org.eclipse.persistence.sessions.DatabaseLogin;

/**
 * This is the awkward way that JPA provides to let us use
 * serializable transactions. At least there is a standard way
 * now, unlike in previous J2EE services.
 *
 */
public class TransactionSessionCustomizer implements SessionCustomizer {
	public TransactionSessionCustomizer() {}

    public void customize(Session session) {
        DatabaseLogin login = (DatabaseLogin)session.getDatasourceLogin();
        System.out.println("Customizing Database Session...");
        System.out.println("Database URL is " + login.getDatabaseURL());
        System.out.println("Now setting future transactions to serializable isolation");
        login.setTransactionIsolation(DatabaseLogin.TRANSACTION_SERIALIZABLE);
        if (login.getTransactionIsolation() != DatabaseLogin.TRANSACTION_SERIALIZABLE)
        	System.out.println("--but not actually set to serializable");
    }
}