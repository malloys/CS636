package cs636.pizza.dao;

import java.util.Set;
import java.util.TreeSet;
import java.util.List;

import javax.persistence.EntityManager;

import cs636.pizza.domain.PizzaOrder;
import cs636.pizza.domain.PizzaSize;
import cs636.pizza.domain.Topping;

//Note: these can throw various subclasses of RuntimeException, 
// as defined by JPA (compare to SQLException of JDBC, a checked exception)
public class PizzaOrderDAO {
	
    private DbDAO dbDAO;
    
	public PizzaOrderDAO(DbDAO db) {
		this.dbDAO = db;
	}
	
  	public void insertOrder(PizzaOrder order) 
	{
		dbDAO.getEM().persist(order);
	}
	
	// Get orders for a certain day and room number
  	// Callers can get toppings as needed by using o.getToppings() (by lazy loading)
  	// while the persistence context is still available (i.e., until commit)
    @SuppressWarnings("unchecked")
	public List<PizzaOrder> findOrdersByRoom(int roomNumber, int day) 
	{
		List<PizzaOrder> orders = dbDAO.getEM().createQuery("select o from PizzaOrder o where o.roomNumber = "
				+ roomNumber + " and o.day = " + day + " order by o.id").getResultList();	
		return orders;
	}
	
	// find first order with specified status
    @SuppressWarnings("unchecked")
	public int findFirstOrder(int status) 
	{
		List<PizzaOrder> orders = dbDAO.getEM().createQuery("select o from PizzaOrder o where o.status = "
				+ status + " order by o.id" ).getResultList();		
		return orders.get(0).getId();
	}
	
	public void updateOrderStatus(int ordNo, int newStatus)
	{
		EntityManager em = dbDAO.getEM();
		PizzaOrder order = (PizzaOrder)em.find(PizzaOrder.class, ordNo);
		order.setStatus(newStatus);
	}
	
	// get all orders between day1 and day2 (inclusive)
    @SuppressWarnings("unchecked")
	public List<PizzaOrder> findOrdersByDays(int day1, int day2) {
		List<PizzaOrder> orders = dbDAO.getEM().createQuery("select o from PizzaOrder o where o.day >= " 
				+ day1 + " and o.day <= " + day2 + " order by o.id" ).getResultList();		
		return orders;
	}
    
    @SuppressWarnings("unchecked")
	public Topping findTopping(String toppingName) {
		EntityManager em = dbDAO.getEM();
		List<Topping> tops = em.createQuery(
				"select t from Topping t where t.toppingName = '" + toppingName
						+ "'").getResultList();
		if (tops.size() == 0)
			return null;
		Topping top = tops.get(0);
		if (top.getStatus() == 0)
			return null; // topping has been deleted
		else
			return top;
	}
    @SuppressWarnings("unchecked")
	public void  createTopping(String toppingName) {
		EntityManager em = dbDAO.getEM();
		List<Topping> tops = em.createQuery(
				"select t from Topping t where t.toppingName = '" + toppingName + "'")
				.getResultList();
		if (tops.size() > 0) {
			tops.get(0).setStatus(1); // make sure found topping is active (not deleted)
		} else { // create new topping
			em.persist(new Topping(toppingName));
		}
	}
    @SuppressWarnings("unchecked")
	public PizzaSize findPizzaSize(String sizeName) {
		EntityManager em = dbDAO.getEM();
		System.out.println("in findPizzaSize");
		List<PizzaSize> list = (List<PizzaSize>) em.createQuery(
				"select s from PizzaSize s where s.sizeName = '" + sizeName
						+ "'").getResultList();
		if (list.size() == 0)
			return null;
		PizzaSize size = list.get(0);
		if (size.getStatus() == 0) // make sure found size is active (not
									// deleted)
			return null; // it's gone
		else
			return size;
	}

    @SuppressWarnings("unchecked")
	public void createPizzaSize(String sizeName) {
		EntityManager em = dbDAO.getEM();
		System.out.println("in createPizzaSize");
		List<PizzaSize> list = (List<PizzaSize> )em.createQuery(
				"select s from PizzaSize s where s.sizeName = '" + sizeName + "'")
				.getResultList();
		if (list.size() > 0) {
			list.get(0).setStatus(1); // make sure found size is active (not deleted)
		} else { // create new size
			em.persist( new PizzaSize(sizeName));
		}
	}
	public void deleteTopping(String toppingName) {
		EntityManager em = dbDAO.getEM();
		Topping top = (Topping) em.createQuery(
				"select t from Topping t where t.toppingName = '" + toppingName + "'")
				.getSingleResult();  // throws if no row
		top.setStatus(0); // mark deleted
	}

	public void deletePizzaSize(String sizeName) {
		EntityManager em = dbDAO.getEM();
		PizzaSize size = (PizzaSize) em.createQuery(
				"select s from PizzaSize s where s.sizeName = '" + sizeName + "'")
				.getSingleResult();  // throws if no row, as we want here
		size.setStatus(0);
	}
	
	@SuppressWarnings("unchecked")
	public Set<PizzaSize> findPizzaSizes() {
		List<PizzaSize> sizes = dbDAO.getEM().createQuery(
				"select s from PizzaSize s where s.status = 1").getResultList();
		return new TreeSet<PizzaSize>(sizes);
	}

	@SuppressWarnings("unchecked")
	public Set<Topping> findToppings() {
		List<Topping> tops = dbDAO.getEM().createQuery(
				"select t from Topping t where t.status = 1")
				.getResultList();
		return new TreeSet<Topping>(tops);
	}

}
