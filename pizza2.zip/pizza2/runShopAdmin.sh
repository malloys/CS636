java -javaagent:lib/eclipselink.jar -cp lib/eclipselink.jar:lib/javax.persistence_2.0.4.v201112161009.jar:lib/hsqldb.jar:bin cs636.pizza.presentation.ShopAdmin

