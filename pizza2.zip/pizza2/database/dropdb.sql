--drop targets of FKs after tables with the FKs
drop table order_topping;	
drop table pizza_orders;
drop table pizza_size;			
drop table toppings;	
drop table pizza_sys_tab;
drop table pizza_id_gen;



