select 'pizza_size' from pizza_size;	
select * from pizza_size;			
select 'toppings' from pizza_size;	
select * from toppings;
select 'pizza_orders' from pizza_size;	
select * from pizza_orders;
select 'order_topping' from pizza_size;	
select * from order_topping;
select 'pizza_sys_tab' from pizza_size;	
select * from pizza_sys_tab;



